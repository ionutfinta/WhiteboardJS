# WhiteboardJS
### Coming soon !
A tiny HTML Witheboard app based on powerfull web modules (Bootstrap, TinyMCE, jQuery-UI).

## Requirements
* NodeJS

## How-to
* For Developpers:
    Run your terminal in a working directory
    ```shell
    > git clone https://github.com/ionutfinta/WhiteboardJS.git ./
    > npm install
    > npm start
    ```

    And browse to [http://127.0.0.1:8080](http://127.0.0.1:8080).

* For Others: A simple .zip that you extract and click on index.html coming soon !


